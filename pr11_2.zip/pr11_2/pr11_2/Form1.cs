﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr11_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Time
        {
            public int chas;
            public int minut;
            public int second;
            public int chas1;
            public int minut1;
            public int second1;
         
            public int Chas1()
            {if (minut + minut1 > 60)
                    chas += chas1 + 1;
                else chas += chas1;
                if (chas > 23 )
                    chas -= 24;
               
                return chas;
            }
            public int Minut1()
            {
               
                if (minut+minut1 > 60)
                {
                    minut = minut + minut1 - 60;
                }
                    else
                minut += minut1;
                if (second + second1 > 60)
                    minut +=  1;
                
                return minut;
            }
            public int Second1()
            {if (second+second1 > 60)   
                    second = second + second1 - 60;
            else
                second += second1;
                return second;
            }
          

        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Time time = new Time();
            time.chas = (int)(numericUpDown1.Value);
            time.minut = (int)(numericUpDown2.Value);
            time.second = (int)(numericUpDown3.Value);
            time.chas1 = (int)(numericUpDown4.Value);
            time.minut1 = (int)(numericUpDown5.Value);
            time.second1 = (int)(numericUpDown6.Value);
            MessageBox.Show(String.Format("Исходное время: {0}:{1}:{2}\n Измененное время: {3}:{4}:{5}", time.chas, time.minut, time.second,time.Chas1(),time.Minut1(),time.Second1()));
        }
    }
}
